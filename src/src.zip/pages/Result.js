import React from "react";

const Result = () =>{
    return (<div>결과 화면입니다.</div>)
}

export default Result;